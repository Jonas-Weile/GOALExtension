meeting(date(15, 02, 2010), time(18,00), duration(4,00), [jane]).
