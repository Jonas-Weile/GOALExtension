% Hanoi game has 3 pins (pin 0, pin 1, pin 2).
pins(2). 

