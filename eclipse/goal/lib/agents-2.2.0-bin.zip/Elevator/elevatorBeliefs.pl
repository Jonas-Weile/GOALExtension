% The direction that will be shown to the people at the next stop.
% This remains the intended direction of movement until there are no more
% planned stops in that direction.
dir(down).
% Initially, it is unknown whether doors are open or closed.
doorState(unknown).