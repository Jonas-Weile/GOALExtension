:- dynamic wumpusIsAlive/0, insideCave/0.

outsideCave :- not(insideCave).
