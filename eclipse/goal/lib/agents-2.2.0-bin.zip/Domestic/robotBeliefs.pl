% The amount of beer in stock.
beerstock(unknown).

% Holds if the fridge is closed; otherwise fridge is open.
fridgeclosed.

% holdingbeer. set when robot is holding a beer. 
% Note that there is no percept informing the agent that a beer
% is being hold and the agent needs to keep track of this itself.

% ownerhasbeer. Holds if the owner has his beer.