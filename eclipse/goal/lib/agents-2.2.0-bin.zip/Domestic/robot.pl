:-dynamic at/1, holdingbeer/0, ownerhasbeer/0, beerstock/1, fridgeclosed/0.
