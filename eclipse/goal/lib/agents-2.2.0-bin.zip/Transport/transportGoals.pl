delivered_order(c1).
delivered_order(c2).