% Declaration of a predicate for counting the number of printed lines.
:-dynamic nrOfPrintedLines/1. 